<!---
Copyright BigchainDB GmbH and BigchainDB contributors
SPDX-License-Identifier: (Apache-2.0 AND CC-BY-4.0)
Code is Apache-2.0 and docs are CC-BY-4.0
--->

# Answer Questions

People ask questions about BigchainDB in the following places:

- Gitter
  - [bigchaindb/bigchaindb](https://gitter.im/bigchaindb/bigchaindb)
  - [bigchaindb/js-bigchaindb-driver](https://gitter.im/bigchaindb/js-bigchaindb-driver)
- [Twitter](https://twitter.com/bigchaindb)
- [Stack Overflow "bigchaindb"](https://stackoverflow.com/search?q=bigchaindb)

Feel free to hang out and answer some questions. People will be thankful.
