# Clusterpost
Execute jobs in remote computing grids using a REST api.   
Data transfer, job execution and monitoring are all handled by clusterpost.   
Clusterpost uses [nodejs](https://nodejs.org/en/) with [Hapijs](http://hapijs.com) in the server side application plus [couchdb](https://couchdb.apache.org/) for storage.  
Cluster post is easy to deploy and will integrate well with existing applications.   
Follow the guide described in doc/ to deploy the application at your site and the computing grid you would like to use.    
#### Supported computing grids
Load Sharing Facility  (LSF) job scheduler. 

Last Updated: 11/27/2019
