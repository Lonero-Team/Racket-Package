# clusterpost-list-react

> clusterpost jobs view

[![NPM](https://img.shields.io/npm/v/clusterpost-list-react.svg)](https://www.npmjs.com/package/clusterpost-list-react) [![JavaScript Style Guide](https://img.shields.io/badge/code_style-standard-brightgreen.svg)](https://standardjs.com)

## Install

```bash
npm install --save clusterpost-list-react
```

## Usage

```jsx
import React, { Component } from 'react'

import MyComponent from 'clusterpost-list-react'

class Example extends Component {
  render () {
    return (
      <MyComponent />
    )
  }
}
```

## License

MIT © [juanprietob](https://github.com/juanprietob)
