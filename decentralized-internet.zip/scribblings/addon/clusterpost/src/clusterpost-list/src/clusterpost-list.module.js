angular.module('clusterpost-list', 
['ui.bootstrap',
  'smart-table',
  'jsonFormatter',
  'jwt-user-login']);