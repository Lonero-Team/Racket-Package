var couchUpdateViews = require('couch-update-views');
couchUpdateViews.couchUpdateViews();