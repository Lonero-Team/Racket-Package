# Reinvent-the-Internet
I want to change the way we transfer wireless data and utilize this for a series of projects
